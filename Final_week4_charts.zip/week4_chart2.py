# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 22:56:57 2024

@author: susda
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 15:54:56 2024

@author: srdavenport
"""

import seaborn as sb
import pandas as pd
import matplotlib.pyplot as plt


base_ex_data = [] #I created two empty lists that will be my x and y axes
names_data = []
g = pd.read_csv('C:/Users/susda/Downloads/wk4/wk4/data/pokemon.csv')
games = pd.read_csv('C:/Users/susda/Downloads/wk4/wk4/data/poke_by_game.csv')

while True:
    n = input("Enter the name of a Pokemon character or type 'exit':\n\ninput: ")
    if n in g['identifier'].values: #if the user input is in 'identifier'...
        base_experience = g.loc[g['identifier'] == n, 'base_experience'].values[0]
        #extracting the name and base experience of desired pokemon
        base_ex_data.append(base_experience) #add the base experience to the list
        names = str(n) #has to be a string for this program
        names = names.capitalize() #capitalize the names
        names_data.append(names) #adding names to the names_data list
        
        
    if len(base_ex_data) > 5: #if the list number gets bigger than 6 we will cut
        print("Stop")
        break
#interpreting the data...
my_palette = "twilight"
sb.barplot(data = games, x=base_ex_data, y=names_data, palette = my_palette)

#We've got our chosen pokemon and their base experience!
#went with a simple barplot
plt.xlabel("Base Experience", weight = "bold", font="Arial", fontsize= 13)
plt.ylabel("Version Count",weight ="bold", fontsize = 13, font = "Arial")
plt.title("Apperances By Pokemon",fontsize=35, color = "0", font = "Arial", weight = "bold")
  
