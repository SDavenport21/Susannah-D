# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 13:37:52 2024

@author: srdavenport
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  8 11:05:19 2024

@author: zana
"""

import pandas as pd
import seaborn as sb
import matplotlib.pyplot as plt

g = pd.read_csv('C:/Users/susda/Downloads/wk4/wk4/data/pokemon.csv')
games = pd.read_csv('C:/Users/susda/Downloads/wk4/wk4/data/poke_by_game.csv')

 
random_list = list(games.sample(n=6)['pokemon_id'])
print(random_list) #this is a list of six random pokemon id (aka their names)

version_count_list = [] #empty list for fun things later

for pokemon_id in random_list: #for each name in random list of names
    games.loc[games['pokemon_id'] == pokemon_id] #filtering games to include 
    #rows where poke_id matches current pokemon_id
    result = games[games['pokemon_id'] == pokemon_id].groupby('version_id')['pokemon_id'].apply(list).reset_index(name='pokemon_id')
    #trudged through old class notes to find this groupby method to get things in order
    #I wasn't sure if this part would be fullly functional but I got the version count
    #that I ultimately needed.
    version_count = result['pokemon_id'].apply(lambda x: pokemon_id in x).sum() #version count summed up
    version_count_list.append(version_count) #appending to the emptyversion count list
    print(version_count)
my_palette = "summer" #making things a little prettier
sb.barplot(data=games,x=random_list,y=version_count_list, palette = my_palette)
plt.xlabel("Pokemon ID", weight = "bold", fontsize = 14, font = "Verdana")
plt.ylabel("Version Count",weight ="bold", fontsize = 14, font = "Verdana")
plt.title("Apperances By Pokemon",fontsize=25, color = "0", font = "Verdana", weight = "bold")




#x-axis can be random_list (names) 
#y-axis can be their version count (version_count)

#versionsplot = print(games.loc[games['pokemon_id']==1,['pokemon_id','version_id']].groupby('pokemon_id').count().reset_index())