# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 23:23:39 2024

@author: susda
"""

#Create a list that will store information about a team. 
#Each team member should have a name and a grade assigned to them. 
#Use this data to create a data frame, which you can then create an 
#appropriate barplot from similar to the two in problems 1 and 2.
import seaborn as sb
import pandas as pd
import matplotlib.pyplot as plt

import random

g = pd.read_csv('C:/Users/susda/Downloads/wk4/wk4/data/pokemon.csv')
games = pd.read_csv('C:/Users/susda/Downloads/wk4/wk4/data/poke_by_game.csv')

poke_team = []

for i in range(35):  # Adjust the range based on how many Pokémon you want to add
    random_name = list(g.sample(n=1)['identifier'])
    random_grade = random.choice(['A', 'B', 'C', 'D', 'F'])
    
    poke = {'Name': str(random_name[0]).capitalize(), 'Grade': random_grade}
    poke_team.append(poke)

poke_team_df = pd.DataFrame(poke_team)
#poke_team is my own little dataframe to work with now.
#I decided to make this a distribution chart.The "for i in range(35) gives us a nice
#wide range of names (or id's) to choose from. The grades are grades like you get in
#regular school...not sure what pokemon school grades look like.


plt.figure(figsize=(10, 6))
sb.set(style="whitegrid") #I really like this look!

ax = sb.countplot(x='Grade', data=poke_team_df, order=['A', 'B', 'C', 'D', 'F'], palette="viridis", 
linewidth=2)
#I like the x-axis tick labels to be bold
#viridis is a really fun color palette!
ax.set_xticklabels(ax.get_xticklabels(), weight="bold")


#all the font is bold because I cant see it otherwise.
plt.xlabel('Grade', weight="bold", fontsize=18)
plt.ylabel('Count of Grades', weight="bold", fontsize=18)
plt.title('Distribution of Grades in the Pokemon Team', weight="bold", fontsize=18)

# Setting thet y-axis ticks to counts of 2 and getting rid of decimals
plt.yticks(range(0, max(poke_team_df['Grade'].value_counts())+2, 2)) #the range
#is 0 to the maximum number of my makeshift dataframe 'Grade' column, plus 2

# Showing the plot...
plt.show()

