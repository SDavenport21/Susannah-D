
"""
PFE
My code with all of my notes
Remember to keep this one for future reference!!!!
*ask prof Auerbeck for help*

@author: zana
"""

import pandas as pd

p = pd.read_csv('data/clean/pokemon.csv')


team = []

while True:
    n = input("What would you like to do:\n\n\t1) Add teammate\n\t2) Exit\n\t3) Manage Team\n\ninput: ")
    ##managing team

    if int(n) == 1: #If true, user chose to add a teammate.
        z = input("What would you like to do:\n\n\t1) Add Teammate\n\t2) Generate Random Team\n\t3) Exit\n\ninput: ")
        #If user chose to add a teammate, user gets asked for another input (z), which is teammate, generate a random team, or exit.
        if int(z) == 1: #prompted to add teammate
            t = input("Who is your teammate: ")
                #checking that the team list does not exceed 6. if it does, that means too many 
            if len(team) == 6:
                print("Too many teammates")
                continue

            if not p.loc[p['identifier'] == t].empty:
                # locate the Pokémon entry in the dataset under 'identifier'
                pokemon_entry = p.loc[p['identifier'] == t]

                # New dictionary made with id and identifier (remember, t is teammate input)
                pokemon_dict = {'id': pokemon_entry['id'].values[0], 'identifier': t}

                # Adding dict to the team list using append method
                team.append(pokemon_dict)

                print(t + " added to the team")
            else:
                print("Please add a valid Pokemon. Input not valid")
            #clearing up conditionals
        elif int(z) == 2:
            random_team = p.sample(n=6)['identifier'].tolist()
            print("Randomly generated team:", random_team)
                #keeping randomly generated team an option
        elif int(z) == 3:
            print("Exiting...")
            print(team)
            break

    elif int(n) == 3:
        #this part of the code deals with team management : specifically, adding or removing nicknames!
        nickname = input("Which Pokemon's nickname do you want to add or remove: ")
        if nickname in [pokemon['identifier'] for pokemon in team]: 
            #pretty self explanatory right here, checking on whereabouts of nickname
            choice_input = input("What would you like to do:\n\t1) Add Nickname\n\t2) Remove Nickname\ninput: ")
            i = [pokemon['identifier'] for pokemon in team].index(nickname) #assigning all this to a simple variable to be used later

            if int(choice_input) == 1:
                chosen_nickname = input("Enter the nickname: ")
                team[i]['chosen_nickname'] = chosen_nickname #remember that chosen nickname is the user's input. user chooses nickname
                print("Your nickname has been added!")

            elif int(choice_input) == 2: #otherwise we will not put in a nickname/gets removed
                team[i]['chosen_nickname'] = None
                print("Nickname has been removed")
        else:
            print("Invalid! Please enter a valid name!") #conditionals, if it's not valid, I have to take care of that issue!!

    elif int(n) == 2:
        print("Exiting...")
        print(team)
        break
