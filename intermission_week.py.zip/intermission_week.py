#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 10:28:39 2024

@author: Susannah
"""
import pandas as pd
p=pd.read_csv('data/orig/pokemon.csv') #I am finally learning how to upload dataframes, yay!

p['identifier'] = p['identifier'].str.capitalize() 
#I used the capitalize method for all of the pokemon names. Originally I was going to 
#have the user's input capitalized after entering it into the program, but
#this seemed like the better choice.
p.to_csv('data/clean/pokemon.csv') #put it back in all nice and clean

team = [] #empty list

while True: ##learning this part of the code in class was AWESOME I was so excited
#to have a foothold! 
   n = input("What would you like to do: \n\n\t1) Add teammate\n\t2) Exit program\n\ninput: ")
   if int(n) ==1: #if the user's input  (n) equals selection 1, prompt for input (t)
        t = input("Who is your teammate? ")
        if t in p['identifier'].values: #if t's name matches any in the pokemon DF 'identifier'....
            print("Great! " + t + " has been added to your team!") #print a return statement w/ name
            team.append(t) #add name to list
            if len(team) >= 3: #checking for max of 3 names in 'team'
                print("You have now registered the maximum amount of teammates. Enjoy your game!")
                break #nice way to exit
   elif int(n) == 2: #if input had been 2, this would show up
        print("Have a great day!")
        break

  
 
    
 
    
 
