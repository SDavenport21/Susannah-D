#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 15:55:28 2024

@author: zana
"""

import pandas as pd

g = pd.read_csv('data/pokemon.csv')

games = pd.read_csv('data/poke_by_game.csv')

base_ex_data = [] #empty list to fill with stuff later
while True:
    n = input("Enter the name of a pokemon character or type 'exit'\n\ninput: ")
    if n == 'exit': #safety net exit
        break
    if n in g['identifier'].values: #if the user input is in 'identifier' column
        base_experience = g.loc[g['identifier'] == n, 'base_experience'].values[0]
        # all the rows with names Aand experience together
        n = n.capitalize() #the lowercase was bothering me
        base_ex_data.append(base_experience)#filling up old empty list!
        print(str(n) + str(base_ex_data))

    else:
        break
   ###base_ex_data updates with each addition. Every name put in by 
   #the user puts out the specific pokemon's base_experience. User can go as
   #long as they want, then exit with 'exit' any time.
   
   
#Once  n + base_experience_data is long enough, we can use one for x-axis
#and one for y-axis
   
