#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 17:27:03 2024

@author: zana
"""
import pandas as pd


import random
g = pd.read_csv('data/pokemon.csv')

games = pd.read_csv('data/poke_by_game.csv')

poke_team = []


for i in range(45): #I want ten pokemon 
    random_name = list(g.sample(n=1)['identifier'])
    random_grade = random.choice(['A', 'B', 'C', 'D', 'E', 'F'])


    poke = {'Name': str(random_name[0]).capitalize(), 'Grade': random_grade}
    poke_team.append(poke)

poke_team_df = pd.DataFrame(poke_team)
p = poke_team_df


grade_counts = p['Grade'].value_counts().sort_index()
print(grade_counts)

#this is how many pokemon's got all the different grades
# (8 of them got an A, for instance)
#This would be a cool histogram!
