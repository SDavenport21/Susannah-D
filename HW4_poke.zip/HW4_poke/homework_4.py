#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  8 11:05:19 2024

@author: zana
"""

import pandas as pd
#import seaborn as sb
import matplotlib.pyplot as plt

g = pd.read_csv('data/pokemon.csv')
games = pd.read_csv('data/poke_by_game.csv')


random_list = list(games.sample(n=6)['pokemon_id'])
print(random_list) #this is a list of six random pokemon id (aka their names)

for pokemon_id in random_list: #for each name in random list of names
    games.loc[games['pokemon_id'] == pokemon_id] #filtering games tp include 
    #rows where poke_id matches current pokemon_id
    result = games[games['pokemon_id'] == pokemon_id].groupby('version_id')['pokemon_id'].apply(list).reset_index(name='pokemon_id')
    version_count = result['pokemon_id'].apply(lambda x: pokemon_id in x).sum() #version count summed up
    print(version_count) #version count is how many times one of those
    #six pokemon ids comes up in the id column

#x-axis can be random_list (names) 
#y-axis can be their version count (version_count)








